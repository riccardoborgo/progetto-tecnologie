#include "Coronavirus.h"
#include <iostream>
#include<string>
using namespace std;


CCoronavirus::CCoronavirus()
{
}


CCoronavirus::~CCoronavirus()
{
}
