#pragma once
#include <iostream>
#include<string>

using namespace std;

class CCoronavirus
{
private:
	
public:
	CCoronavirus();
	~CCoronavirus();
	void modificaDisponibilit�(CData data);
	void aggiungiDisponibilit�(CData data);
	void annullaDisponibilit�(CData data);

};

