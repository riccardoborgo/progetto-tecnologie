#pragma once
#include <iostream>
#include<string>

class CCalendario
{
private:

public:
	CCalendario();
	~CCalendario();
	void visualizza();
};

