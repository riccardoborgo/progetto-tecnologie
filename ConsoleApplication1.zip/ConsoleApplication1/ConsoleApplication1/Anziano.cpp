#include "Anziano.h"



CAnziano::CAnziano()
{
}


CAnziano::~CAnziano()
{
}

void CAnziano::modificaRichiesta(CData data, string listaDellaSpesa[])
{
}

void CAnziano::aggiungiRichiesta(CData data, string listaDellaSpesa[], string indirizzo, string regione, string nTelefono)
{
}

void CAnziano::annullaRichiesta(CData data)
{
}
