#include "Lavoratore.h"



CLavoratore::CLavoratore()
{
}


CLavoratore::~CLavoratore()
{
}

void CLavoratore::modificaDisponibilit�(CData data)
{
}

void CLavoratore::aggiungiDisponibilit�(CData data)
{
}

void CLavoratore::annullaDisponibilit�(CData data)
{
}

void CLavoratore::visualizzaCalendario(CCalendario calendario)
{
}
