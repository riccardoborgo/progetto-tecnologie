﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CAlimento
{
    class CAlimenti
    {
        private
            CData scadenza;
            string nome;
        public
        CAlimenti();
        CAlimenti(CData scadenza, string nome);
        visualizzaAlimento();



    }
}
