#include "CCalendario.h"

CCalendario::CCalendario()
{
}

string CCalendario::visualizzaCalendatrio()
{
	return string();
}

string CCalendario::viusalizzaDateMese(int mese)
{
	return string();
}

CData CCalendario::visualizzaData(CData data)
{
	return CData();
}

CPrenotazione CCalendario::visualizzaPrenotazione(CPrenotazione prenotazione)
{
	return CPrenotazione();
}

void CCalendario::rimuoviPrenotazione(CPrenotazione prenotazione)
{
}

void CCalendario::spostaPrenotazione(CPrenotazione prenotazione, CData dataNuova)
{
}

void CCalendario::accettaPrenotazione(CPrenotazione prenotazione, CLavoratore lavoratore)
{
}

void CCalendario::rimuoviServizio(CPrenotazione prenotazione, CLavoratore lavoratore)
{
}

void CCalendario::confermaSerivzioEffettuato(CPrenotazione prenotazione)
{
}
