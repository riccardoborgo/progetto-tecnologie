#pragma once
#define MAXEL 100000
#include <iostream>
#include <string>
using namespace std;
class CCalendario
{
private:
	CData calendario[MAXEL]; //vettore di CData che rappresentano tutte le date prenotate

public:
	CCalendario();
	void aggiungiPrenotazione(CPrenotazione prenotazione);//metodo per aggiungere una prenotazione al calendario
	string visualizzaCalendatrio(); //visualizza tutte le richieste di servizio
	string viusalizzaDateMese(int mese); //visualizza tutte le richieste di servizio in un mese specifico
	CData visualizzaData(CData data); //visualizza un servizio in una data specifica
	CPrenotazione visualizzaPrenotazione(CPrenotazione prenotazione);//visualizza una specifica prenotazione
	void rimuoviPrenotazione(CPrenotazione prenotazione); //rimuove una prenotazione
	void spostaPrenotazione(CPrenotazione prenotazione, CData dataNuova); //sposta una prenotazione passando la data nuova
	void accettaPrenotazione(CPrenotazione prenotazione, CLavoratore lavoratore); //il lavoretore si rende disponibile in una determinata prenotazioone
	void rimuoviServizio(CPrenotazione prenotazione, CLavoratore lavoratore);//il lavoratore rimuove la sua disponibilit� in per una prenotazione
	void confermaSerivzioEffettuato(CPrenotazione prenotazione);//rimuove la prenotazione e invia una notifica di spesa avvenuta
};

