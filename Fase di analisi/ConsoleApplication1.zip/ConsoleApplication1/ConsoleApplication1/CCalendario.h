//Giovanni F. Cappellini
#pragma once

class CCalendario
{
private:
	

public:
	//Costruttori
	CCalendario();

	//Metodi
	void visualizza();

	//Distruttori
	~CCalendario();
};

