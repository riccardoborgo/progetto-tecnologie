//Giovanni F. Cappellini
#include "CLavoratore.h"


CLavoratore::CLavoratore()
{
}

void CLavoratore::modificaDisponibilita(CData data)
{

}

void CLavoratore::aggiungiDisponibilita(CData data)
{

}

void CLavoratore::annullaDisponibilit�(CData data)
{

}

void CLavoratore::visualizzaCalendario(CCalendario calendario)
{

}


CLavoratore::~CLavoratore()
{
}
