//Giovanni F. Cappellini
#include "CCoronavirus.h"


CCoronavirus::CCoronavirus()
{
}




CCoronavirus::~CCoronavirus()
{
}
