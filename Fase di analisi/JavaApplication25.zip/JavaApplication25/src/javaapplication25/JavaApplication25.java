/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication25;

/**
 *
 * @author Giovanni F. Cappellini 4^A Informatica 28 aprile 2020
 */
public class JavaApplication25 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        int MAXEL = 100;
        JAnziano anziano = new JAnziano();
        JLavoratore lavoratore = new JLavoratore();
        String[] spesa = new String[MAXEL];
        
        anziano.aggiungiRichiesta(JData(12, 12, 2020), spesa, "indirizzo", "regione", "nTelefono");
        anziano.modificaRichiesta(JData(11, 12, 2020), spesa);
        lavoratore.aggiungiDisponibilita(JData(12, 12, 2020));
    }
    
}
