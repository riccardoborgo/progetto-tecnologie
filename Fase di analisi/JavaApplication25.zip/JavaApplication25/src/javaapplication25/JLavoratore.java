/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication25;

/**
 *
 * @author Giovanni F. Cappellini
 */
public class JLavoratore 
{
    //Attributi
    private String nome, cognome, email, password;
    private String regione, nTelefono;
    private String listaDellaSpesa[];
    
    //Costruttori
    public JLavoratore()
    {
        
    }
    
    //Metodi
    public void modificaDisponibilita(JData data)
    {
        
    }
    
    public void aggiungiDisponibilita(JData data)
    {
        
    }
    
    public void annullaDisponibilita(JData data)
    {
        
    }
    
    public void visualizzaCalendario(JCalendario calendario)
    {
        
    }
}
