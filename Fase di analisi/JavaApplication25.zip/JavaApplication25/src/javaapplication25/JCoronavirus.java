/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication25;

/**
 *
 * @author Giovanni F. Cappellini
 */
public class JCoronavirus 
{
    //Attributi
    
    
    //Metodi
    public JCoronavirus()
    {
        
    }
    
    public void modificaDisponibilita(JData data)
    {
        
    }
    
    public void aggiungiDisponibilita(JData data)
    {
        
    }
    
    public void annullaDisponibilita(JData data)
    {
        
    }
}
