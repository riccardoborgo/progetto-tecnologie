/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication25;

/**
 *
 * @author Giovanni F. Cappellini
 */
public class JAnziano 
{
    //Attributi
    private String nome, cognome, email, password;
    private String regione, nTelefono, indirizzo;
    private String listaDellaSpesa[];
    
    //Costruttori
    public JAnziano()
    {
        
    }
    
    //Metodi
    public void modificaRichiesta(JData data, String listaDellaSpesa[])
    {
        
    }
    
    public void aggiungiRichiesta(JData data, String listaDellaSpesa[], String indirizzo, String regione, String nTelefono)
    {
        
    }
    
    public void annullaRichiesta(JData data)
    {
        
    }
}
