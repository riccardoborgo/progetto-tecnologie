/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication25;

/**
 *
 * @author Giovanni F. Cappellini
 */
public class JData 
{
    //Attributi
    private int g, m, a;
    
    //Costruttori
    public JData()
    {
        g = 0;
        m = 0;
        a = 0;
    }
    
    public JData(int g, int m, int a)
    {
        this.g = g;
        this.m = m;
        this.a = a;
    }
    
    //Metodi
    public String toString()
    {
        String s = "";
        s = g + "/" + m + "/" + a;
        return s;
    }
}
